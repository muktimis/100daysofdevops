{{- define "platform.service" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "platform.fullname" . }}
  labels:
    {{- include "platform.labels" . | nindent 4 }}
spec:
  selector:
    {{- include "platform.selectorLabels" . | nindent 4 }}
  ports:
    - port: {{ .Values.service.port | default 80 }}
      targetPort: http
{{- end }}
